
(* Module de la passe de placement mémoire *)
(* doit être conforme à l'interface Passe *)
open Tds
open Ast
open Type
open Exceptions

type t1 = Ast.AstType.programme
type t2 = Ast.AstPlacement.programme

           

(* analyse_placement_instruction : int -> string -> AstType.instruction -> AstPlacement.instruction -> int *)
(* Paramètre dep : le deplacement à utiliser *)
(* Paramètre reg : registre utiliser *)
(* Paramètre i : l'instruction à analyser *)
(* Vérifie le placement mémoire de l'instruction et tranforme l'instruction
en un couple d'instruction de type AstPlacement.instruction et le deplacement utilisé *)
(* Erreur si mauvais placement mémoiire *)
let rec analyse_placement_instruction dep reg i =
  match i with
  | AstType.Declaration (ia, e) ->
    begin
    match info_ast_to_info ia with
    | InfoVar(_,t,_,_) ->  
        (* Modifier l'adresse de la variable dans la table des symboles *)
        modifier_adresse_variable dep reg ia;
        (* Retourner l'AST de placement de la déclaration et la taille du type *)
        (AstPlacement.Declaration(ia, e), getTaille t)
    | _ -> raise (ErreurInatenduInfo ia)
    end
  | AstType.Affectation (a, e) -> (AstPlacement.Affectation(a, e), 0)
  | AstType.Empty -> (AstPlacement.Empty, 0)
  | AstType.AffichageInt e -> (AstPlacement.AffichageInt e, 0)
  | AstType.AffichageRat e -> (AstPlacement.AffichageRat e, 0)
  | AstType.AffichageBool e -> (AstPlacement.AffichageBool e, 0)
  | AstType.Conditionnelle (c, b1, b2) -> 
      (* Analyser les blocs conditionnelse *)
      (AstPlacement.Conditionnelle(c, analyse_placement_bloc dep reg b1, analyse_placement_bloc dep reg b2), 0)
  | AstType.TantQue (c, b) -> 
      (* Analyser le bloc de la boucle TantQue  *)
      (AstPlacement.TantQue(c, analyse_placement_bloc dep reg b), 0)
  | AstType.Retour (e, ia) ->
    begin
      match info_ast_to_info ia with
      |  InfoFun(_, t, lt) ->
          (* Retourner l'AST de placement pour le retour avec la taille totale des types *)
          (AstPlacement.Retour(e, getTaille t, List.fold_right (+) (List.map Type.getTaille lt) 0), 0)
      | _ -> raise (ErreurInatenduInfo ia)
    end
  | AstType.For (ia, e1, e2, e3, b) -> 
    begin 
    match info_ast_to_info ia with
    | InfoVar(_,_,_,_) -> 
        (* Modifier l'adresse de la variable dans la table des symboles *)
        modifier_adresse_variable dep reg ia;
        (* Analyser récursivement le bloc de la boucle For *)
        let nb = analyse_placement_bloc (dep+1) reg b in
        (* Retourner l'AST de placement pour la boucle For *)
        (AstPlacement.For(ia,e1,e2,e3,nb) , 0)
    | _ -> raise (ErreurInatenduInfo ia)
    end
  | AstType.Goto id -> 
      (* Retourner l'AST de placement pour l'instruction Goto *)
      (AstPlacement.Goto(id),0)
  | AstType.Etiquette id -> 
      begin
        match info_ast_to_info id with
        | InfoVar(_, t, _, _) -> 
            (* Modifier l'adresse de la variable dans la table des symboles *)
            modifier_adresse_variable dep reg id;
            (* Retourner l'AST de placement pour l'étiquette avec la taille du type *)
            (AstPlacement.Etiquette(id), getTaille t)
        | _ -> raise (MauvaiseUtilisationEtiquette id)
      end





(* analyse_placement_instruction : int -> string -> AstType.bloc -> AstPlacement.bloc -> int *)
(* Paramètre dep : le deplacement à utiliser *)
(* Paramètre reg : registre utiliser *)
(* Paramètre li : le bloc à analyser *)
(* Vérifie le placement mémoire du bloc et tranforme le bloc
en un couple de bloc de type AstPlacement.bloc et le deplacement utilisé *)
(* Erreur si mauvais placement mémoire *)
and analyse_placement_bloc dep reg li =
  
  match li with
  | [] -> [], 0
  | t::q -> let (i1, d1) = analyse_placement_instruction dep reg t in let (nli, d) = analyse_placement_bloc (dep + d1) reg q in
  (i1::nli, d1 + d)
  


let analyse_seul_param dep reg p =
  match info_ast_to_info p with
| InfoVar(_,t,_,_) -> modifier_adresse_variable (-dep - getTaille t) reg p ; getTaille t
| _ -> raise (ErreurInatenduInfo p)




(* analyse_tds_fonction : AstType.fonction -> AstPlacement.fonction *)
(* Paramètre : la fonction à analyser *)
(* Vérifie le placement mémoire de la fonction et tranforme la fonction
 en une fonction de type AstPlacement.fonction *)
(* Erreur si mauvais placement mémoire*)

let analyse_placement_fonction (AstType.Fonction(ia, lp, li)) =
  let rec analyse_parametres dep reg lp =
    match lp with
    | [] -> ()
    | t::q -> let d = analyse_seul_param dep reg t in analyse_parametres (dep + d) reg q in
  (analyse_parametres 0 "LB" (List.rev lp)) ;
   AstPlacement.Fonction(ia, lp, analyse_placement_bloc 3 "LB" li)


(* analyser : AstType.programme -> AstPlacement.programme *)
(* Paramètre : le programme à analyser *)
(* Vérifie le placement mémoire et tranforme le programme
en un programme de type AstPlacement.programme *)
(* Erreur si mauvais placement mémoire *)
let analyser (AstType.Programme (fonctions,prog)) =
  let nf = List.map analyse_placement_fonction fonctions in
  let nb = analyse_placement_bloc 0 "SB" prog in
  AstPlacement.Programme(nf, nb)

  
  