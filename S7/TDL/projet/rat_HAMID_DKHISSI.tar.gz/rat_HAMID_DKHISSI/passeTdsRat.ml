(* Module de la passe de gestion des identifiants *)
(* doit être conforme à l'interface Passe *)
open Tds
open Exceptions
open Ast

type t1 = Ast.AstSyntax.programme
type t2 = Ast.AstTds.programme


(* analyse_tds_affectable : tds -> AstSyntax.affectable -> AstTds.affectable *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre a : l'affectable à analyser *)
(* Vérifie la bonne utilisation des affectable et tranforme l'affectable
en un affectable de type AstTds.affectable *)
(* Erreur si mauvaise utilisation des identifiants *)
let rec analyse_tds_affectable tds a =
  match a with
  | AstSyntax.Ident id ->
    begin
      match chercherGlobalement tds id with
        | None -> raise (IdentifiantNonDeclare id)
        | Some info ->
        begin
          match info_ast_to_info info with
            |InfoConst _ -> 
                (* Identifiant trouvé, retourner l'AST correspondant *)
                AstTds.Ident info
            |InfoVar _ ->
                (* Identifiant trouvé, retourner l'AST correspondant *)
                AstTds.Ident info
            |InfoFun _  ->
                (* Mauvaise utilisation de l'identifiant s'il s'agit d'une fonction *)
                raise (MauvaiseUtilisationIdentifiant id)
        end
    end 
 | AstSyntax.Dereference a ->
    (* Analyser récursivement l'affectable déréférencé *)
    let na = analyse_tds_affectable tds a in
    AstTds.Dereference na
 | AstSyntax.Tab (a,e) ->
    (* Analyser récursivement l'affectable de tableau et l'expression d'indice *)
    let na = analyse_tds_affectable tds a in
    let ne = analyse_tds_expression tds e in
    AstTds.Tab (na, ne)


(* analyse_tds_expression : tds -> AstSyntax.expression -> AstTds.expression *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre e : l'expression à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme l'expression
en une expression de type AstTds.expression *)
(* Erreur si mauvaise utilisation des identifiants *)
and analyse_tds_expression tds e = match e with
  (* Appel de fonction représenté par le nom de la fonction et la liste des paramètres réels *)
  | AstSyntax.AppelFonction (id, lp) ->( match (chercherGlobalement tds id) with
    |None -> raise (IdentifiantNonDeclare id)
    |Some infoast -> (match (info_ast_to_info infoast) with
              |InfoFun _ -> (let nl =  List.map (fun e -> analyse_tds_expression tds e) lp in
                        (AstTds.AppelFonction( infoast, nl)))
              |_ -> raise (MauvaiseUtilisationIdentifiant id)))
  (* Booléen *)
  | AstSyntax.Booleen b-> AstTds.Booleen b
  (* Opération unaire représentée par l'opérateur et l'opérande *)
  | AstSyntax.Unaire (o,e) -> (AstTds.Unaire(o, (analyse_tds_expression tds e)))
  (* Opération binaire représentée par l'opérateur, l'opérande gauche et l'opérande droite *)
  | AstSyntax.Binaire (o,exp1,exp2) -> 
      (let nexp1 = analyse_tds_expression tds exp1 in
      let nexp2 = analyse_tds_expression tds exp2 in
      AstTds.Binaire(o,nexp1,nexp2))
  (*Entier*)
  | AstSyntax.Entier n -> AstTds.Entier n

  | AstSyntax.Affectable a -> AstTds.Affectable(analyse_tds_affectable tds a)
  | AstSyntax.New n -> AstTds.New n
  | AstSyntax.Null -> AstTds.Null
  | AstSyntax.Adresse id -> 
    begin
      match chercherGlobalement tds id with
      |None -> raise (IdentifiantNonDeclare id)
      |Some ia -> 
        begin
          match info_ast_to_info ia with
          |InfoVar _ -> AstTds.Adresse ia
          | _ -> raise (MauvaiseUtilisationIdentifiant id)
        end
      end
  | AstSyntax.Creation (t,e) ->  let ne=analyse_tds_expression tds e in AstTds.Creation(t, ne)
  | AstSyntax.Initialisation le -> let nle = (List.map (analyse_tds_expression tds) le) in AstTds.Initialisation nle



(* analyse_tds_instruction : tds -> tds -> info_ast option -> AstSyntax.instruction -> AstTds.instruction *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre oia : None si l'instruction i est dans le bloc principal,
                   Some ia où ia est l'information associée à la fonction dans laquelle est l'instruction i sinon *)
(* Paramètre i : l'instruction à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme l'instruction
en une instruction de type AstTds.instruction *)
(* Erreur si mauvaise utilisation des identifiants *)
let rec analyse_tds_instruction tds tdsgoto oia i =
  match i with
  | AstSyntax.Declaration (t, n, e) ->
      begin
        match chercherLocalement tds n with
        | None ->
            (* L'identifiant n'est pas trouvé dans la tds locale,
            il n'a donc pas été déclaré dans le bloc courant *)
            (* Vérification de la bonne utilisation des identifiants dans l'expression *)
            (* et obtention de l'expression transformée *)
            let ne = analyse_tds_expression tds e in
            (* Création de l'information associée à l'identfiant *)
            let info = InfoVar (n,Undefined, 0, "") in
            (* Création du pointeur sur l'information *)
            let ia = info_to_info_ast info in
            (* Ajout de l'information (pointeur) dans la tds *)
            ajouter tds n ia;
            (* Renvoie de la nouvelle déclaration où le nom a été remplacé par l'information
            et l'expression remplacée par l'expression issue de l'analyse *)
            AstTds.Declaration (t, ia, ne)
        | Some _ ->
            (* L'identifiant est trouvé dans la tds locale,
            il a donc déjà été déclaré dans le bloc courant *)
            raise (DoubleDeclaration n)
      end
  | AstSyntax.Affectation (a,e) ->
    (* Vérification de la bonne utilisation des identifiants dans l'expression *)
    (* et obtention de l'expression transformée *)
    let ne = analyse_tds_expression tds e in
    (* Vérification de la bonne utilisation des identifiants dans l'affectable *)
    (* et obtention de l'affectable transformé *)
      let na = analyse_tds_affectable tds a in
      begin 
        match na with 
        |AstTds.Ident ia ->
            begin 
              match info_ast_to_info ia with 
              | InfoVar _ -> AstTds.Affectation (na, ne)
              | InfoConst(s,_) -> raise (MauvaiseUtilisationIdentifiant s)
              | InfoFun(s,_,_) -> raise (MauvaiseUtilisationIdentifiant s)
            end
        |AstTds.Dereference _ -> AstTds.Affectation (na, ne)
        |AstTds.Tab (_,_) -> AstTds.Affectation (na,ne) 
      end
  | AstSyntax.Constante (n,v) ->
      begin
        match chercherLocalement tds n with
        | None ->
          (* L'identifiant n'est pas trouvé dans la tds locale,
             il n'a donc pas été déclaré dans le bloc courant *)
          (* Ajout dans la tds de la constante *)
          ajouter tds n (info_to_info_ast (InfoConst (n,v)));
          (* Suppression du noeud de déclaration des constantes devenu inutile *)
          AstTds.Empty
        | Some _ ->
          (* L'identifiant est trouvé dans la tds locale,
          il a donc déjà été déclaré dans le bloc courant *)
          raise (DoubleDeclaration n)
      end
  | AstSyntax.Affichage e ->
      (* Vérification de la bonne utilisation des identifiants dans l'expression *)
      (* et obtention de l'expression transformée *)
      let ne = analyse_tds_expression tds e in
      (* Renvoie du nouvel affichage où l'expression remplacée par l'expression issue de l'analyse *)
      AstTds.Affichage (ne)
  | AstSyntax.Conditionnelle (c,t,e) ->
      (* Analyse de la condition *)
      let nc = analyse_tds_expression tds c in
      (* Analyse du bloc then *)
      let tast = analyse_tds_bloc tds tdsgoto oia t in
      (* Analyse du bloc else *)
      let east = analyse_tds_bloc tds tdsgoto oia e in
      (* Renvoie la nouvelle structure de la conditionnelle *)
      AstTds.Conditionnelle (nc, tast, east)
  | AstSyntax.TantQue (c,b) ->
      (* Analyse de la condition *)
      let nc = analyse_tds_expression tds c in
      (* Analyse du bloc *)
      let bast = analyse_tds_bloc tds tdsgoto oia b in
      (* Renvoie la nouvelle structure de la boucle *)
      AstTds.TantQue (nc, bast)
  | AstSyntax.Retour (e) ->
      begin
      (* On récupère l'information associée à la fonction à laquelle le return est associée *)
      match oia with
        (* Il n'y a pas d'information -> l'instruction est dans le bloc principal : erreur *)
      | None -> raise RetourDansMain
        (* Il y a une information -> l'instruction est dans une fonction *)
      | Some ia ->
        (* Analyse de l'expression *)
        let ne = analyse_tds_expression tds e in
        AstTds.Retour (ne,ia)
      end
  | AstSyntax.For(n1, n2, e1, e2, e3, b) -> 
    begin
      match chercherGlobalement tds n1 with (*On cherche globalement si n1 est deja declaré dans la tds*)
        (*si oui on lève une exception*)
        (*on a choisi ceci pour que les valeur des id dans la tds puisse etre utilisé dans la boucle *)
        |Some _-> raise (DoubleDeclaration(n1))
        (*si non*)
        |None -> 
          (*on verifie si les deux identifiants sont les memes*)
          if (n1=n2) then
        (*On cree unr tds fille pour le bloc for*)
          let tdsfille = creerTDSFille tds in let indice = info_to_info_ast (InfoVar(n1,Undefined,0,""))
          in ajouter tdsfille n1 indice ;
          let (ne1,ne2,ne3)=(analyse_tds_expression tdsfille e1,analyse_tds_expression tdsfille e2,analyse_tds_expression tdsfille e3) in
          let nb = analyse_tds_bloc tdsfille tdsgoto oia b in
          AstTds.For(indice, ne1, ne2, ne3, nb)
        
          else 
          raise (MauvaiseUtilisationIdentifiant n2) 
          end
  | AstSyntax.Goto id -> let info = InfoVar (id,Undefined, 0, "") in 
      let ia = info_to_info_ast info in
        AstTds.Goto(ia)
          
  | AstSyntax.Etiquette n ->
    begin 
    match chercherGlobalement tdsgoto n with
     |None -> let info = InfoVar (n,Undefined, 0, "") in
      let ia = info_to_info_ast info in
      ajouter tdsgoto n ia;
      AstTds.Etiquette(ia)
     |Some _ -> raise (DoubleDeclaration n)
      end
      


(* analyse_tds_bloc : tds -> tds -> info_ast option -> AstSyntax.bloc -> AstTds.bloc *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre oia : None si le bloc li est dans le programme principal,
                   Some ia où ia est l'information associée à la fonction dans laquelle est le bloc li sinon *)
(* Paramètre li : liste d'instructions à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme le bloc en un bloc de type AstTds.bloc *)
(* Erreur si mauvaise utilisation des identifiants *)
and analyse_tds_bloc tds tdsgoto oia li =
  (* Entrée dans un nouveau bloc, donc création d'une nouvelle tds locale
  pointant sur la table du bloc parent *)
  let tdsbloc = creerTDSFille tds in
  (* Analyse des instructions du bloc avec la tds du nouveau bloc.
     Cette tds est modifiée par effet de bord *)
   let nli = List.map (analyse_tds_instruction tdsbloc tdsgoto oia) li in
   (* afficher_locale tdsbloc ; *) (* décommenter pour afficher la table locale *)
   nli


(* analyse_tds_fonction : tds -> tds -> -> AstSyntax.fonction -> AstTds.fonction *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre : la fonction à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme la fonction
en une fonction de type AstTds.fonction *)
(* Erreur si mauvaise utilisation des identifiants *)
let analyse_tds_fonction maintds tdsgoto (AstSyntax.Fonction(t,n,lp,li))  =
match chercherLocalement maintds n with
| None -> let info = InfoFun(n,Undefined,[]) in
  let infoast = (info_to_info_ast info) in
    ajouter maintds n infoast;
    let tdsfille = creerTDSFille maintds in
      let lpa = List.map (fun (x,y) -> 
        let infovar = InfoVar(y,Undefined,0,"") in 
        begin
          match chercherLocalement tdsfille y with
          | None -> 
          let info = info_to_info_ast infovar in
          ajouter tdsfille y info;
          (x,info)
          |Some _ -> raise (DoubleDeclaration y)
          end) lp in
        Ast.AstTds.Fonction (t,infoast,lpa,(analyse_tds_bloc tdsfille tdsgoto (Some infoast) li))
| Some _-> raise (DoubleDeclaration n)

(* analyser : AstSyntax.programme -> AstTds.programme *)
(* Paramètre : le programme à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme le programme
en un programme de type AstTds.programme *)
(* Erreur si mauvaise utilisation des identifiants *)
let analyser (AstSyntax.Programme (fonctions,prog)) =
  let tds = creerTDSMere () in
  let tdsgoto = creerTDSMere() in
  let nf = List.map (analyse_tds_fonction tds tdsgoto) fonctions in
  let nb = analyse_tds_bloc tds tdsgoto None prog in
  AstTds.Programme (nf,nb)

  
