  open Tds
  open Ast
  open AstType
  open Type
  open Exceptions
  
  type t1 = Ast.AstTds.programme
  type t2 = Ast.AstType.programme
  
  
  (* analyse_tds_affectable : tds -> AstSyntax.affectable -> AstTds.affectable *)
  (* Paramètre tds : la table des symboles courante *)
  (* Paramètre a : l'affectable à analyser *)
  (* Vérifie la bonne utilisation des types des affectables et tranforme l'affectable
  en un affectable de type AstType.affectable *)
  (* Erreur si mauvaise utilisation des identifiants *)
  let rec analyse_type_affectable a =
    match a with 
    |AstTds.Ident i -> 
      begin
      match info_ast_to_info i with
      | InfoVar(_,t,_,_) -> (AstType.Ident i), t
      | InfoConst(_,_) -> (AstType.Ident i), Int
      | InfoFun(_,t,_) -> (AstType.Ident i), t
      end
    | AstTds.Tab (a,e) -> 
      begin
        let (na,nt) = analyse_type_affectable a in
        let (ne,te) = analyse_type_expression e in
      match nt,te with
      |Tableau t,Int -> (AstType.Tab (na, ne), t);
      | _ -> raise (TypeInattendu(nt,Tableau Undefined))
      end
    | AstTds.Dereference (a) -> begin
      let (na,nt) = analyse_type_affectable a in
    match nt with
    |Pointeur t -> (AstType.Dereference na), t;
    | _ -> raise (TypeInattendu(nt,Pointeur Undefined))
    end
    

  
  (* analyse_type_expression : AstTds.expression -> AstType.expression -> typ *)
  (* Paramètre e : l'expression à analyser *)
  (* Vérifie la bonne utilisation des types et tranforme l'expression
  en une expression de type AstType.expression *)
  (* Erreur si mauvaise utilisation des types *)
 and analyse_type_expression e = match e with
    (* Appel de fonction représenté par le nom de la fonction et la liste des paramètres réels *)
    | AstTds.AppelFonction (infoast, lp) -> 
      begin
      (match info_ast_to_info infoast with
        |InfoFun(_,tr,lpe)-> let l  = List.split (List.map  analyse_type_expression lp) in
                       let ln = fst l in 
                       let lt = snd l in
                       begin
                        match (est_compatible_list lt lpe) with
                        |false -> raise (TypesParametresInattendus(lt,lpe))
                        |true ->(AstType.AppelFonction(infoast,ln),tr)
                       end
        |_ -> raise (ErreurInatenduInfo infoast))
             end
    (* Booléen *)
    | AstTds.Booleen b-> (AstType.Booleen b,Bool)
    | AstTds.Unaire (o, e) ->
      (let (ne, te) = analyse_type_expression e in
      if (est_compatible te Rat) then
        let (u, tp) =
        begin
          match o with
          | AstSyntax.Numerateur -> (AstType.Numerateur, Int)
          | AstSyntax.Denominateur -> (AstType.Denominateur,Int)
        end
        in (AstType.Unaire(u, ne), tp)
      else raise (TypeInattendu(te, Rat)))
    (*Entier*)
    |AstTds.Entier n -> (AstType.Entier n, Int)
    (* Opération binaire représentée par l'opérateur, l'opérande gauche et l'opérande droite *)
    | AstTds.Binaire (operateur,exp1,exp2) ->
      (let (ne1,te1) =  analyse_type_expression exp1 in
      let (ne2,te2) =  analyse_type_expression exp2 in
      (*On vérifie si les deux opérandes sont de meme type*)
      if est_compatible te1 te2 then
      begin
      ( match operateur with
      |Plus -> (match te1, te2 with
          |Int,Int ->(AstType.Binaire(PlusInt, ne1 , ne2), Int)
          |Rat,Rat ->(AstType.Binaire(PlusRat, ne1 , ne2), Rat)
          |_ -> raise (TypeBinaireInattendu(Plus,te1,te2)))
      |Mult -> (match te1, te2 with
          |Int,Int ->(AstType.Binaire(MultInt, ne1 , ne2), Int)
          |Rat,Rat ->(AstType.Binaire(MultRat, ne1 , ne2), Rat)
          |_ -> raise( TypeBinaireInattendu(Mult,te1,te2)))  
      |Equ -> (match te1, te2 with
          |Int,Int ->(AstType.Binaire(EquInt, ne1 , ne2), Bool)
          |Bool,Bool ->(AstType.Binaire(EquBool, ne1 , ne2), Bool)
          |_ -> raise (TypeBinaireInattendu(Equ,te1,te2)))
      |Fraction -> (match te1,te2 with
          |Int,Int -> (AstType.Binaire(Fraction,ne1,ne2), Rat)
          |_ -> raise (TypeBinaireInattendu(Fraction,te1,te2)))
      |Inf -> (if est_compatible te1 Int && est_compatible te2 Int then 
        (Binaire(Inf,ne1,ne2),Bool)  
        else raise (TypeBinaireInattendu(Inf,te1,te2)) ))
      end    
      (*si c'est pas le cas une exception est levée*)  
      else raise (TypeBinaireInattendu(operateur,te1,te2)))
    | AstTds.Affectable a -> let (na,t) = analyse_type_affectable a in (AstType.Affectable na), t
    | AstTds.Null -> AstType.Null, Pointeur Undefined
    | AstTds.New t -> AstType.New t, Pointeur t
    | AstTds.Adresse a -> 
      begin
      match info_ast_to_info a with
                      |InfoVar(_,t,_,_) -> AstType.Adresse a, Pointeur t
                      |_ -> raise (ErreurInatenduInfo a)
      end
    | AstTds.Creation (t,e) -> let (ne,te)= analyse_type_expression e in
    if not (est_compatible te Int) then raise (TypeInattendu(te,Int)) else 
      (AstType.Creation(t,ne),Tableau t)
    | AstTds.Initialisation le   -> 
      let nle = List.map (analyse_type_expression) le in
      let ln=List.map (fst) (nle) in let nt=List.map snd nle in
     if List.for_all (fun x -> x = List.hd nt) nt then (AstType.Initialisation ln,Tableau (List.hd nt))
     else raise (TypeInattenduTableau(Undefined))
    
  
  (* analyse_type_instruction : AstTds.instruction -> AstType.instruction *)
  (* Paramètre i : l'instruction à analyser *)
  (* Vérifie la bonne utilisation des types et tranforme l'instruction
  en une instruction de type AstType.expression *)
  (* Erreur si les types ne sont pas compatibles *)
let rec analyse_type_instruction i = match i with
    | AstTds.Declaration (t, n, e) -> (let (ne,te) = (analyse_type_expression e) in
      (*Après l'analyse de l'expression, on vérifie si les types sont compatibles*)
      if (est_compatible t te) then 
        let _ = modifier_type_variable t n in
          AstType.Declaration(n,ne)
      else (raise (TypeInattendu(te,t))))
    | AstTds.Affectation (a,e) -> 
      (*on analyse l'affectable et l'expression à affecter*)
        let (na,nt1) = analyse_type_affectable a in let (ne,nt2) = analyse_type_expression e in
        if est_compatible nt1 nt2 then
          AstType.Affectation(na,ne)
        else raise (TypeInattendu(nt2,nt1))
    | AstTds.Affichage e -> 
      (*analyse de l'expression pour récuperer le type de e*)
      let (ne,te) = analyse_type_expression e in
      (*appel de Affichage compatible avec le type de l'expression*) 
         begin 
          match te with
          |Int -> AffichageInt ne
          |Bool -> AffichageBool ne
          |Rat -> AffichageRat ne
          |Undefined ->  raise(TypeInattendu(te,te))
          | _ -> raise(AffichageImpossibleDuType te) 
         end
    | AstTds.Conditionnelle (c,t,e) -> 
      (let (nc,tc) = analyse_type_expression c in
      (*On vérifie que la condition est bien booleane*)
        if est_compatible Bool tc         
        then (let bloca = analyse_type_bloc t  in   
        let bloc = analyse_type_bloc e  in 
        AstType.Conditionnelle(nc,bloca,bloc))            
      else raise( TypeInattendu(tc,Bool) ) )  
    | AstTds.TantQue (c,b) -> (let (nc,tc) = analyse_type_expression c in
      (*On vérifie que la condition d'arret est bien booleane*)
      if est_compatible Bool tc 
        then (let bloca = analyse_type_bloc b in 
        AstType.TantQue(nc,bloca))
        else raise (TypeInattendu(tc,Bool)))  
    | AstTds.Retour (e,n) -> 
      ( (*Analyse du type de l'expression de retour*)
      let (ne, te) = analyse_type_expression e in
      let (tr, _) = (match info_ast_to_info n with
        | InfoFun(_, t_r, lt_param) ->
          if (est_compatible t_r Undefined) then raise (TypeUndefined Undefined)
          else (t_r, lt_param)
        | _ -> raise (ErreurInatenduInfo n)) in
          if (est_compatible te tr) then
          AstType.Retour(ne, n)
          else raise (TypeInattendu(te, tr)))
        (*Pour la constante*)
    |AstTds.Empty  -> AstType.Empty
    |AstTds.For(ia,e1,e2,e3,b) -> let (ne1,te1) = (analyse_type_expression e1) in
    if (not (est_compatible Int te1)) then raise (TypeInattendu(te1,Int))
    else let _ = modifier_type_variable Int ia in let (ne2,te2) = (analyse_type_expression e2) in 
    if not(est_compatible Bool te2) then raise (TypeInattendu(te2,Bool))
    else let (ne3,te3) = analyse_type_expression e3 in 
    if not(est_compatible Int te3) then raise (TypeInattendu(te3,Int))
    else let nb = analyse_type_bloc b in AstType.For(ia,ne1,ne2,ne3,nb)
    
    (*On a choisi de considérer le type comme Undefined*)
    |AstTds.Goto id -> 
    begin
    match info_ast_to_info id with
            | InfoVar(_,t,_,_) -> if (t = Undefined) then AstType.Goto(id) 
                                        else raise (TypeInattendu(t, Undefined))
            | _ -> raise (MauvaiseUtilisationEtiquette id)
    end
    (*Rien à changer puisque elle est déjà typé par Undefined*)
    |AstTds.Etiquette n -> AstType.Etiquette(n)
      
      
      (* analyse_type_bloc : AstTds.bloc -> AstType.bloc *)
      (* Paramètre li : liste d'instructions à analyser *)
      (* Vérifie la bonne utilisation des types et tranforme le bloc en un bloc de type AstType.bloc *)
      (* Erreur si mauvaise utilisation des types *)
      and analyse_type_bloc li =(List.map analyse_type_instruction li)
      
      
      (* analyse_tds_fonction : AstTds.fonction -> AstType.fonction *)
      (* Paramètre : la fonction à analyser *)
      (* Vérifie la bonne utilisation des types et tranforme la fonction
      en une fonction de type AstType.fonction *)
      (* Erreur si mauvaise utilisation des types *)
      let analyse_type_fonction (AstTds.Fonction (r, infoast, lp, b)) =
        (* Définition du type de chaque paramètre de la fonction (contenu dans la liste lp)
           à l'info lui correspondant *)
        List.iter (fun (x,y) -> modifier_type_variable x y) lp;
        (* Séparation de la liste des infos et de la liste des types à partir de lp *)
        let (lt,li) = List.split lp in
            (* Définition du type de retour et des types des paramètres dans l'info de la fonction *)
            modifier_type_fonction r lt infoast;
        (* Transformation de la fonction *)
        let nb = analyse_type_bloc b in
            (* Renvoie un AstType.Fonction contenant l'info de la fonction, la liste des infos des paramètres et le
               nouveau bloc *)
        AstType.Fonction(infoast, li, nb)
     
      
      (* analyser : AstTds.programme -> AstType.programme *)
      (* Paramètre : le programme à analyser *)
      (* Vérifie la bonne utilisation des identifiants et tranforme le programme
      en un programme de type AstTds.programme *)
      (* Erreur si mauvaise utilisation des identifiants *)
      let analyser (AstTds.Programme (fonctions,prog)) =
        let nf = List.map (analyse_type_fonction) fonctions in
        let nb = analyse_type_bloc prog in
        Programme (nf,nb)
        
