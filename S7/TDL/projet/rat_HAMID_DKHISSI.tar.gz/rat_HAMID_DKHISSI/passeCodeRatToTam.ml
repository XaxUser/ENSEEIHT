
open Tds
open Ast
open Code
open Type
open Tam
open Exceptions
type t1 = Ast.AstPlacement.programme
type t2 = string



(* getTypeAff : AstPlacement.affectable -> typ *)
(* Paramètre a : l'affectable qu'on veut extraire le type *)
(* extraction du type d'un affectable *)
(*Erreur si mauvais code (mauvais matching)*)

let rec getTypeAff a = 
  match a with
  | AstType.Ident ia ->
    begin
      match info_ast_to_info ia with
      | InfoVar (_, t, _, _) -> t
      | InfoConst (_,_) -> Int
      | _ -> raise (ErreurInatenduInfo ia)
    end
  |AstType.Dereference a -> getTypeAff a
  |AstType.Tab (a,_) -> begin
    match getTypeAff a with
    |Tableau t -> t
    |_ -> raise (TypeIsNotTable (getTypeAff a))
  end



(* getTypeExp : AstPlacement.expression -> typ *)
(* Paramètre e : l'expression qu'on veut extraire le type *)
(* extraction du type d'une expression *)
(*Erreur si mauvais code (mauvais matching)*)
let rec getTypeExp e = 
  match e with 
  AstType.Entier _ -> Int
| AstType.Booleen _ -> Bool
| AstType.Unaire (_,_) -> Int
| AstType.Binaire (o,_,_) -> 
  begin
    match o with
    | PlusInt -> Int
    | PlusRat -> Rat
    | MultInt -> Int
    | MultRat -> Rat
    | EquInt -> Bool
    | EquBool -> Bool
    | Inf -> Bool
    | Fraction -> Rat
  
  end
| AstType.AppelFonction (infoast, _) ->
  begin
    match info_ast_to_info infoast with
    | InfoFun(_, t , _) -> t
    | _ -> raise (ErreurInatenduInfo infoast)
  end
| AstType.Adresse a -> 
    begin
    match info_ast_to_info a with
    | InfoVar(_,t,_,_) -> t
    | _ -> raise (ErreurInatenduInfo a)
    end 
| AstType.Affectable a -> getTypeAff a
| AstType.Null -> Pointeur Undefined
| AstType.New t -> Pointeur t

| AstType.Creation (t, _) -> Tableau t 
| AstType.Initialisation ti-> Tableau (getTypeExp (List.hd(ti)))



(* analyse_code_affectable : AstType.affectable -> bool -> string *)
(* Paramètre a : l'affectable à analyser *)
(* Paramètre modifiable : est-que l'affectable est modifiable *)
(* Analyser le code RAT d'un affectable et le transformer en code TAM *)
(* Erreur si mauvaise utilisation des identifiants *)

let rec analyse_code_affectable a modifiable =
  match a with
  | AstType.Ident ia ->
    begin
      match info_ast_to_info ia with
      | InfoVar (_, t, dep, reg) -> if modifiable 
        then store (getTaille t) dep reg 
        else load (getTaille t) dep reg
      | InfoConst (_,i) -> loadl_int i
      | _ -> raise (ErreurInatenduInfo ia)
    end
  | AstType.Dereference a -> let t = getTypeAff a in
  begin
     match t with
    | Pointeur _ -> let n = analyse_code_affectable a false in 
    if modifiable then n^storei (getTaille t) 
    else n^loadi (getTaille t)  
    | _ -> raise (TypeIsNotPointer t)
  end

  | Tab (a, e) -> 
    begin
       let tama = analyse_code_affectable a false in 
       let tame = analyse_code_expression e in
       let t = getTypeAff a in
       match t with
       |Tableau tab -> 
         begin
           if (modifiable=false) then
             tama ^ loadl_int(getTaille tab) ^ tame ^ subr "IMul" 
             ^ subr "IAdd" ^loadi(getTaille tab)
           else 
             tama ^ loadl_int(getTaille tab) ^ tame ^ subr "IMul" 
             ^ subr "IAdd" ^storei(getTaille tab) 
         end  
       | _-> raise (TypeInattenduTableau(Tableau Undefined))  
       end


(* analyse_code_expression : AstPlacement.expression -> string *)
(* Paramètre e : l'expression à analyser *)
(* Analyser le code RAT d'une expression et le transforme en code TAM *)
(*Erreur si mauvais code (mauvais matching)*)
and analyse_code_expression e =
  match e with
  | AstType.Entier n -> 
      loadl_int n
  | AstType.Booleen b ->
    begin
     if b then loadl_int 1
     else loadl_int 0
    end 
  | AstType.Unaire (o,e) -> 
    begin
      let c = (analyse_code_expression e) in
      c^(match o with
      | Numerateur -> pop 0 1
      | Denominateur -> pop 1 1
      )
    end
  | AstType.Binaire (o,e1,e2) -> 
    begin
      let c1 = (analyse_code_expression e1) in
      let c2 = (analyse_code_expression e2) in
      c1^c2^(match o with
      | PlusInt -> subr "Iadd"
      | PlusRat -> call "ST" "Radd"
      | MultInt -> subr "Imul"
      | MultRat -> call "ST" "Rmul"
      | EquInt -> subr "Ieq"
      | EquBool -> subr "Ieq"
      | Inf -> subr "Ilss"
      | Fraction -> ""
      )
    end
  | AstType.AppelFonction (infoast, le) ->
    begin
      let c = (String.concat "" (List.map analyse_code_expression le)) in
      match info_ast_to_info infoast with
      | InfoFun(str, _ , _) -> c^(call "ST" str) 
      | _ -> raise (ErreurInatenduInfo infoast)
    end
  | AstType.Affectable a -> analyse_code_affectable a false
  | AstType.Null -> ""
  | AstType.New t -> let taille = getTaille t in loadl_int taille ^ subr "Malloc"
  | AstType.Adresse a -> 
    begin
    match info_ast_to_info a with
    | InfoVar(_,_,d,r) -> loada d r
    | _ -> raise (ErreurInatenduInfo a)
    end

  | AstType.Creation (t, e) -> begin
    let ne = analyse_code_expression e in
    let taille = getTaille t in 
    (ne ^ (loadl_int taille) ^ (subr "IMul") ^ (subr "Malloc"))
  end
  | AstType.Initialisation ti-> 
    begin 
    let l1 = List.map analyse_code_expression ti in
    let taille = getTaille (getTypeExp (List.hd ti))* List.length l1 in (loadl_int taille)^subr "Malloc" ^ 
    String.concat "" l1 ^ loada (-1-taille) "ST" ^ loadi 1 ^ storei taille
    end 


(*  getTypeExp (List.hd l1)*)

(* analyse_code_instruction : AstPlacement.instruction -> string *)
(* Paramètre i : l'instruction à analyser *)
(* Analyser le code RAT d'une instruction et le transforme en code TAM *)
(*Erreur si mauvais code (mauvais matching)*)
 
and analyse_code_instruction i =
  match i with
  | AstPlacement.Declaration (infoast, e) ->
    begin
    match info_ast_to_info infoast with
    | InfoVar(_,t,dep,reg) -> push (getTaille t)^(analyse_code_expression e)
     ^ (store (getTaille t) dep reg)
    | _ -> raise (ErreurInatenduInfo infoast)
    end
  | AstPlacement.Affectation (a,e) -> (analyse_code_expression e)^(analyse_code_affectable a true)
  | AstPlacement.AffichageInt e ->
    begin
    let ne = (analyse_code_expression e) in
    ne ^ subr "IOut"
    end
  | AstPlacement.AffichageRat e ->
    begin
      let ne = (analyse_code_expression e) in
      ne^ call "ST" "ROut"
      end
  | AstPlacement.AffichageBool e ->
      begin
        let ne = (analyse_code_expression e) in
        ne^subr "BOut"
       end
  | AstPlacement.Conditionnelle (c,t,e) ->
    begin
      let sinon = getEtiquette() in
      let fin = getEtiquette() in
      analyse_code_expression c
      ^ jumpif 0 sinon
      ^ analyse_code_bloc t
      ^ jump fin 
      ^ sinon ^ "\n"
      ^ analyse_code_bloc e
      ^ fin ^ "\n"
    end
  | AstPlacement.TantQue (c,b) ->
    begin
      let whilee = getEtiquette() in
      let endwhile = getEtiquette() in
      whilee ^ "\n"
      ^analyse_code_expression c
      ^ jumpif 0 endwhile
      ^ analyse_code_bloc b
      ^ jump whilee
      ^ endwhile ^ "\n"
    end
  | AstPlacement.Retour (e,tr,tp) -> 
    let ne = (analyse_code_expression e) in
    ne ^ return tr tp
  | AstPlacement.Empty -> "" 
  | AstPlacement.For(infoast,e1,e2,e3,b) -> 
    begin
      match info_ast_to_info infoast with
      | InfoVar(_,t,dep,reg) -> let fore = getEtiquette() and endfor = getEtiquette()
    in  push (getTaille t)^(analyse_code_expression e1)
       ^ (store (getTaille t) dep reg) ^  fore ^ "\n"
       ^analyse_code_expression e2
       ^ jumpif 0 endfor
       ^ analyse_code_bloc b
       ^ analyse_code_expression e3 ^ store (getTaille t) dep reg
       ^ jump fore  
       ^ endfor ^ "\n"
      | _ -> raise (ErreurInatenduInfo infoast)
      end 
  
  | AstPlacement.Goto id -> 
    (match info_ast_to_info id with
    | InfoVar(n,_,_,_) -> jump ("Etiquette" ^ n) (*Avant d'ajouter le mot etiquette, un des tests de
       l'enoncé du projet ne marchait pas parce qu'il leve une double declaration de fin *)
    | _ -> raise (ErreurInatenduInfo id))
  | AstPlacement.Etiquette id -> (match info_ast_to_info id with
    | InfoVar(n,_,_,_) -> label ("Etiquette" ^ n)
    | _ -> raise (MauvaiseUtilisationEtiquette id))



(* analyse_code_bloc : AstPlacement.bloc -> string *)
(* Paramètre li : bloc à analyser *)
(* Paramètre tailleBloc : taille du bloc à analyser *)
(* Analyser le code RAT d'un bloc et le transforme en code TAM *)
and analyse_code_bloc (li,tailleBloc) =
    String.concat "" (List.map analyse_code_instruction li)
    ^ (pop 0 tailleBloc)


(* analyser_code_fonction : AstPlacement.fonction -> string *)
(* Paramètre : la fonction à analyser *)
(* Analyser le code RAT d'une fonction et le transforme en code TAM *)
(*Erreur si mauvais code (mauvais matching)*)
let analyse_code_fonction (AstPlacement.Fonction(infoast, _, (li, _))) =
  match info_ast_to_info infoast with
    | InfoFun(n, _, _) ->
      n ^ "\n"
      ^ String.concat "" (List.map (analyse_code_instruction) li)
      ^ halt
    | _ -> raise (ErreurInatenduInfo infoast)

(* analyser : AstPlacement.programme -> string *)
(* Paramètre p : le programme à analyser *)
(* Analyser le code RAT d'un programme et le transforme en code TAM *)

let analyser (AstPlacement.Programme(fonctions, bloc)) =
  getEntete()
  ^ String.concat "" (List.map analyse_code_fonction fonctions)
  ^ "main \n"
  ^ analyse_code_bloc bloc
  ^ halt
