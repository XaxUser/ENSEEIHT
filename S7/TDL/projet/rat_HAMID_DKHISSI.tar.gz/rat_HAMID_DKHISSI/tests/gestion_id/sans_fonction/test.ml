open Rat
open Compilateur
open Exceptions

exception ErreurNonDetectee

(****************************************)
(** Chemin d'accès aux fichiers de test *)
(****************************************)

let pathFichiersRat = "../../../../../tests/gestion_id/sans_fonction/fichiersRat/"


(**********)
(*  TESTS *)
(**********)

(*Tests Pointeur*)

let%test_unit "testPointeur1" = 
  let _ = compiler (pathFichiersRat^"testPointeur1.rat") in ()

let%test_unit "testPointeur2"= 
  try 
    let _ = compiler (pathFichiersRat^"testPointeur2.rat") 
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("px") -> ()

let%test_unit "testPointeur3"= 
  try 
    let _ = compiler (pathFichiersRat^"testPointeur3.rat") 
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("t") -> ()

let%test_unit "testPointeur4"= 
  try 
    let _ = compiler (pathFichiersRat^"testPointeur4.rat") 
    in raise ErreurNonDetectee
  with
  | DoubleDeclaration("px") -> ()

let%test_unit "testPointeur5"= 
  try 
    let _ = compiler (pathFichiersRat^"testPointeur5.rat") 
    in raise ErreurNonDetectee
  with
  | MauvaiseUtilisationIdentifiant("x") -> ()

let%test_unit "testPointeur6"= 
  try 
    let _ = compiler (pathFichiersRat^"testPointeur6.rat") 
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("y") -> ()

let%test_unit "testPointeur7" = 
  let _ = compiler (pathFichiersRat^"testPointeur7.rat") in ()

let%test_unit "testPointeur8" = 
  let _ = compiler (pathFichiersRat^"testPointeur8.rat") in ()

(*Testes utilisation pointeur*)

let%test_unit "testUtilisationPointeur1" = 
  let _ = compiler (pathFichiersRat^"testUtilisationPointeur1.rat") in ()

let%test_unit "testUtilisationPointeur2" = 
  let _ = compiler (pathFichiersRat^"testUtilisationPointeur2.rat") in ()

let%test_unit "testUtilisationPointeur3"= 
  try 
    let _ = compiler (pathFichiersRat^"testUtilisationPointeur3.rat") 
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("px") -> ()


let%test_unit "testUtilisationPointeur4" = 
  let _ = compiler (pathFichiersRat^"testUtilisationPointeur4.rat") in ()

let%test_unit "testUtilisationPointeur5" = 
  let _ = compiler (pathFichiersRat^"testUtilisationPointeur5.rat") in ()

let%test_unit "testUtilisationPointeur6" = 
  let _ = compiler (pathFichiersRat^"testUtilisationPointeur6.rat") in ()


let%test_unit "testUtilisationPointeur7"= 
  try 
    let _ = compiler (pathFichiersRat^"testUtilisationPointeur7.rat") 
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("y") -> ()

(*-----------------------------------------------------------------------------------*)

(*Tests de la boucle for*)

let%test_unit "testFor1" = 
  let _ = compiler (pathFichiersRat^"testFor1.rat") in ()
  
let%test_unit "testFor2"= 
  try 
    let _ = compiler (pathFichiersRat^"testFor2.rat") 
    in raise ErreurNonDetectee
  with
  | MauvaiseUtilisationIdentifiant("y") -> ()  
  
let%test_unit "testFor3" = 
  let _ = compiler (pathFichiersRat^"testFor3.rat") in ()

let%test_unit "testFor4" = 
  let _ = compiler (pathFichiersRat^"testFor4.rat") in ()

let%test_unit "testFor5" = 
  let _ = compiler (pathFichiersRat^"testFor5.rat") in ()

let%test_unit "testFor6"= 
  try 
    let _ = compiler (pathFichiersRat^"testFor6.rat") 
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("t") -> ()
  
let%test_unit "testFor7"= 
  try 
    let _ = compiler (pathFichiersRat^"testFor7.rat") 
    in raise ErreurNonDetectee
  with
  | DoubleDeclaration("x") -> ()

let%test_unit "testFor8"= 
  try 
    let _ = compiler (pathFichiersRat^"testFor8.rat") 
    in raise ErreurNonDetectee
  with
  | DoubleDeclaration("x") -> ()

let%test_unit "testFor9" = 
  let _ = compiler (pathFichiersRat^"testFor9.rat") in ()
(*
let%test_unit "testFor10"= 
  try 
    let _ = compiler (pathFichiersRat^"testFor10.rat") 
    in raise ErreurNonDetectee
  with
  | DoubleDeclaration("x") -> ()
*)

let%test_unit "testFor11" = 
  let _ = compiler (pathFichiersRat^"testFor11.rat") in ()

let%test_unit "testFor12"= 
  try 
    let _ = compiler (pathFichiersRat^"testFor12.rat") 
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("y") -> ()

(*-----------------------------------------------------------------------------------*)
(*Tests pour les tableaux*)
let%test_unit "testTab" = 
  let _ = compiler (pathFichiersRat^"testTab.rat") in ()

let%test_unit "testTab1" = 
  let _ = compiler (pathFichiersRat^"testTab1.rat") in ()

let%test_unit "testTab2" = 
  let _ = compiler (pathFichiersRat^"testTab2.rat") in ()

let%test_unit "testTab3" = 
  let _ = compiler (pathFichiersRat^"testTab3.rat") in ()
 
let%test_unit "testTab4" = 
  let _ = compiler (pathFichiersRat^"testTab4.rat") in ()

let%test_unit "testTab5"= 
  try 
    let _ = compiler (pathFichiersRat^"testTab5.rat") 
    in raise ErreurNonDetectee
  with
  | DoubleDeclaration("t") -> ()

let%test_unit "testTab6" = 
  let _ = compiler (pathFichiersRat^"testTab6.rat") in ()
  
let%test_unit "testTab7"= 
  try 
    let _ = compiler (pathFichiersRat^"testTab5.rat") 
    in raise ErreurNonDetectee
  with
  | DoubleDeclaration("t") -> ()

(*------------------------------------------------------------------------------------*)

(*Tests goto*)

let%test_unit "testgoto" = 
  let _ = compiler (pathFichiersRat^"testgoto.rat") in ()


let%test_unit "testgoto1"= 
  try 
    let _ = compiler (pathFichiersRat^"testgoto1.rat") 
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("a") -> ()

let%test_unit "testgoto2" = 
  let _ = compiler (pathFichiersRat^"testgoto2.rat") in ()

  let%test_unit "testgoto3"= 
  try 
    let _ = compiler (pathFichiersRat^"testgoto3.rat") 
    in raise ErreurNonDetectee
  with
  | DoubleDeclaration("etiq") -> ()
  
let%test_unit "testgoto4" = 
  let _ = compiler (pathFichiersRat^"testgoto4.rat") in ()
  
  
let%test_unit "testgoto5" = 
  let _ = compiler (pathFichiersRat^"testgoto5.rat") in ()

let%test_unit "testgoto6" = 
  let _ = compiler (pathFichiersRat^"testgoto6.rat") in ()

let%test_unit "testgoto7"= 
  try 
    let _ = compiler (pathFichiersRat^"testgoto7.rat") 
    in raise ErreurNonDetectee
  with
  | DoubleDeclaration("x") -> ()
(*--------------------------------------------------------------------------------------*)
let%test_unit "testAffectation1" = 
  let _ = compiler (pathFichiersRat^"testAffectation1.rat") in ()

let%test_unit "testAffectation2"= 
  try 
    let _ = compiler (pathFichiersRat^"testAffectation2.rat") 
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("y") -> ()

let%test_unit "testAffectation3" = 
  let _ = compiler (pathFichiersRat^"testAffectation3.rat") in ()

let%test_unit "testAffectation4" = 
  try 
    let _ = compiler (pathFichiersRat^"testAffectation4.rat")
    in raise ErreurNonDetectee
  with
  | MauvaiseUtilisationIdentifiant("x") -> ()

let%test_unit "testUtilisation1" = 
  let _ = compiler (pathFichiersRat^"testUtilisation1.rat") in ()

let%test_unit "testUtilisation2" = 
  let _ = compiler (pathFichiersRat^"testUtilisation2.rat") in ()

let%test_unit "testUtilisation3" = 
  try 
    let _ = compiler (pathFichiersRat^"testUtilisation3.rat")
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("y") -> ()

let%test_unit "testUtilisation10" = 
  try 
    let _ = compiler (pathFichiersRat^"testUtilisation10.rat")
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("x") -> ()

let%test_unit "testUtilisation11" = 
  try 
    let _ = compiler (pathFichiersRat^"testUtilisation11.rat")
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("z") -> ()

let%test_unit "testUtilisation12" = 
  try 
    let _ = compiler (pathFichiersRat^"testUtilisation12.rat")
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("z") -> ()

let%test_unit "testUtilisation13" = 
  try 
    let _ = compiler (pathFichiersRat^"testUtilisation13.rat")
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("z") -> ()

let%test_unit "testUtilisation14" = 
  try 
    let _ = compiler (pathFichiersRat^"testUtilisation14.rat")
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("z") -> ()

let%test_unit "testUtilisation15" = 
  try 
    let _ = compiler (pathFichiersRat^"testUtilisation15.rat")
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("z") -> ()

let%test_unit "testUtilisation16" = 
  try 
    let _ = compiler (pathFichiersRat^"testUtilisation16.rat")
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("y") -> ()

let%test_unit "testUtilisation17" = 
  try 
    let _ = compiler (pathFichiersRat^"testUtilisation17.rat")
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("y") -> ()

let%test_unit "testUtilisation18" = 
  try 
    let _ = compiler (pathFichiersRat^"testUtilisation18.rat")
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("y") -> ()

let%test_unit "testUtilisation19" = 
  try 
    let _ = compiler (pathFichiersRat^"testUtilisation19.rat")
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("y") -> ()

let%test_unit "testRecursiviteVariable" = 
  try 
    let _ = compiler (pathFichiersRat^"testRecursiviteVariable.rat")
    in raise ErreurNonDetectee
  with
  | IdentifiantNonDeclare("x") -> ()

(* Fichiers de tests de la génération de code -> doivent passer la TDS *)
open Unix
open Filename

let rec test d p_tam = 
  try 
    let file = readdir d in
    if (check_suffix file ".rat") 
    then
    (
     try
       let _ = compiler  (p_tam^file) in (); 
     with e -> print_string (p_tam^file); print_newline(); raise e;
    )
    else ();
    test d p_tam
  with End_of_file -> ()

let%test_unit "all_tam" =
  let p_tam = "../../../../../tests/tam/sans_fonction/fichiersRat/" in
  let d = opendir p_tam in
  test d p_tam
