import pandas as pd 
from scipy.spatial.distance import pdist, squareform
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np

# extraire les trois tableaux '.csv'
tableau_high = pd.read_csv('topology_high.csv')
tableau_avg = pd.read_csv('topology_avg.csv')
tableau_low = pd.read_csv('topology_low.csv')

def tracer_graphe (tableau, portee, ax, titre):
    """
    Cette methode trace un graphe en 3D à travers le tableau de données, la portée,
    le repere et le titre.

    Args:
        tableau (int): Le premier nombre.
        portee (int): La portée du graphe.
        ax = Le repère.
        titre = le titre de la figure.
          
    """   
    # extraire les données en dataframe
    frame = pd.DataFrame(tableau)
    # Extraire les coordonnées
    coordonnee = frame[['x' , 'y' , 'z']]
    # Calculer les distances entre les points à travers les coordonnées en un vecteur
    Distances= pdist(coordonnee)
    # Construire la matrice d'adjascence
    matriceDist = squareform(Distances)
    G = (matriceDist<= portee)
    
    # Extraire les coordonnées dans les vecteurs
    x_array = coordonnee['x'].to_numpy()
    y_array = coordonnee['y'].to_numpy()
    z_array = coordonnee['z'].to_numpy()

    # Ajouter des noeuds pour chaque point en 3D
    for i in range(len(x_array)):
        ax.scatter(x_array[i], y_array[i], z_array[i], s=10, label=str(i))
        #Ajout de l'identifiant de chaque position
        ax.text(x_array[i], y_array[i], z_array[i], str(frame.loc[i, 'sat_id']), color='red', fontsize=8)

    # Ajout des arêtes du graphe
    for i in range(len(G)):
        for j in range(i+1, len(G[i])):
            if G[i, j] == 1:
                ax.plot([x_array[i], x_array[j]], [y_array[i], y_array[j]],
                        [z_array[i], z_array[j]], 'k-' ,linewidth=0.5)
                
    # Definir le titre            
    ax.set_title(titre)


# Création d'une figure 3D Pour toplogy_high pour les trois portées
fig = plt.figure()
ax1 = fig.add_subplot(131, projection='3d')
tracer_graphe(tableau_high, 20000,ax1, 'toplogy_high à portée 20000')
ax2 = fig.add_subplot(132, projection='3d')
tracer_graphe(tableau_high, 40000,ax2, 'toplogy_high à portée 40000')
ax3= fig.add_subplot(133, projection='3d')
tracer_graphe(tableau_high, 60000,ax3, 'toplogy_high à portée 60000')
plt.tight_layout()



# Création d'une figure 3D Pour toplogy_avg pour les trois portées
fig = plt.figure()
ax1 = fig.add_subplot(131, projection='3d')
tracer_graphe(tableau_avg, 20000,ax1, 'toplogy_avg à portée 20000')
ax2 = fig.add_subplot(132, projection='3d')
tracer_graphe(tableau_avg, 40000,ax2, 'toplogy_avg à portée 40000')
ax3= fig.add_subplot(133, projection='3d')
tracer_graphe(tableau_avg, 60000,ax3, 'toplogy_avg à portée 60000')
plt.tight_layout()


# Création d'une figure 3D Pour toplogy_low pour les trois portées
fig = plt.figure()
ax1 = fig.add_subplot(131, projection='3d')
tracer_graphe(tableau_low, 20000,ax1, 'toplogy_low à portée 20000')
ax2 = fig.add_subplot(132, projection='3d')
tracer_graphe(tableau_low, 40000,ax2, 'toplogy_low à portée 40000')
ax3= fig.add_subplot(133, projection='3d')
tracer_graphe(tableau_low, 60000,ax3, 'toplogy_low à portée 60000')
plt.tight_layout()


# Affichage des figures
plt.show()